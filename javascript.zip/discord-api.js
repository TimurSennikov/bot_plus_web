import { GameDig } from 'gamedig';
import { Client, GatewayIntentBits } from 'discord.js';

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

const prefix = "!";

client.on("ready", function(){
	console.log("Logged in as " + client.user.tag + ".");
});

var ServerInfo = {
	numplayers: 0,
	maxplayers: 0,
	players: [],
	map: "NO DATA",
	stat: true,
	messages: [],

	fetch: function(){
		GameDig.query({
			type: 'garrysmod',
			host: '91.211.118.150',
			port: 27053,
			retry: 10
		}).then((state) => {
			ServerInfo.map = state.map;
			ServerInfo.numplayers = state.numplayers;
			ServerInfo.maxplayers = state.maxplayers;
			ServerInfo.players = state.players;

			ServerInfo.stat = true;
		}).catch((error) => {
			console.log(error);
			ServerInfo.stat = false;
		});
	},

	prettyInfo: function(){
		var playerList = "";

		for(var i = 0; i < ServerInfo.players.length; i++){
			var name = ServerInfo.players[i].name;

			if(name){
				playerList += "**" + ServerInfo.players[i].name + "**" + "\n";
			}
		}

		return playerList;
	},

	serverStateInfo: function(){
		if(ServerInfo.stat){
			return "# На данный момент сервер **работает**";
		}
		else{
			return "# На данный момент сервер **не работает**";
		}
	},

	prepareMessage: function(){
		if(ServerInfo.stat){
			return ServerInfo.serverStateInfo() + "\n" + " Карта: **" + ServerInfo.map + "**, " + "\n" + "Онлайн сервера: **" + ServerInfo.numplayers + "/" + ServerInfo.maxplayers + "**. Игроки : \n" + ServerInfo.prettyInfo();
		}
		else{
			return ServerInfo.serverStateInfo();
		}
	},

	updateMessages: function(){
		for(var i = 0; i < ServerInfo.messages.length; i++){
			var message = ServerInfo.messages[i];

			message.edit(ServerInfo.prepareMessage());
		}
	}
};

client.on("messageCreate", message => {
        if(!message.author.bot){
                if(message.content.startsWith(prefix + "serverinfo")){
			message.channel.send(ServerInfo.prepareMessage()).then((msg) => {ServerInfo.messages.push(msg);});
		}
        }
});

setInterval(ServerInfo.fetch, 10000);
setInterval(ServerInfo.updateMessages, 15000);

client.login("MTI2OTYyNDAwOTYxMjMzMzA1Nw.GnnJfI.VcTt_eAXwBd47EmwtqndkOCVoSRWypk11N_dkE");
